import os
import sys
from tkinter import messagebox

import pandas as pd
from PIL._tkinter_finder import tk
from PyQt5.QtCore import QBuffer, QIODevice
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QFileDialog, \
    QMessageBox, QComboBox
from PyQt5.QtGui import QPixmap, QImage
import cv2
import numpy as np

#------------Standart sigmoid----------------------------------------------
def contrast_enhancement(image_path, alpha=19, beta=0.6):
    # Resmi yükle
    image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)

    # Sigmoid fonksiyonunu uygula
    enhanced_image = standard_sigmoid(image / 255.0, alpha, beta)

    # Piksel değerlerini 0-255 aralığına getir
    enhanced_image = (enhanced_image * 255).astype(np.uint8)

    return enhanced_image

def standard_sigmoid(x, alpha=1, beta=0):
    return 1 / (1 + np.exp(-alpha * (x - beta)))
#------------Standart sigmoid----------------------------------------------



#------------Yatay Kaydırılmış Sigmoid----------------------------------------------
def shifted_sigmoid(image, alpha=11, beta=0.6, gamma=1):
    # Sigmoid fonksiyonunu uygula
    enhanced_image = shifted_sigmoid_function(image / 255.0, alpha, beta, gamma)

    # Piksel değerlerini 0-255 aralığına getir
    enhanced_image = (enhanced_image * 255).astype(np.uint8)

    return enhanced_image

def shifted_sigmoid_function(x, alpha=1, beta=0, gamma=1):
    return 1 / (1 + np.exp(-alpha * (x - beta))) ** (1 / gamma)
#------------Yatay Kaydırılmış Sigmoid----------------------------------------------


#------------Eğimli Sigmoid Fonksiyonu----------------------------------------------
def sloped_sigmoid(image, alpha=12, beta=0.6, gamma=1):
    # Sigmoid fonksiyonunu uygula
    enhanced_image = sloped_sigmoid_function(image / 255.0, alpha, beta, gamma)

    # Piksel değerlerini 0-255 aralığına getir
    enhanced_image = (enhanced_image * 255).astype(np.uint8)

    return enhanced_image

def sloped_sigmoid_function(x, alpha=1, beta=0, gamma=1):
    return 1 / (1 + np.exp(-alpha * (x - beta))) ** gamma
#------------Eğimli Sigmoid Fonksiyonu----------------------------------------------



#------------Kendi Fonksiyonum---------------------------------------------
def custom_contrast(image, alpha=12, beta=0.6, gamma=1):
    print("3")
    # Özgün S-Curve fonksiyonunu uygula
    enhanced_image = custom_s_curve(image / 255.0, alpha, beta, gamma)

    # Piksel değerlerini 0-255 aralığına getir
    enhanced_image = (enhanced_image * 255).astype(np.uint8)

    return enhanced_image

def custom_s_curve(x, alpha=1, beta=0, gamma=1):
    print("4")

    # Özgün S-Curve fonksiyonunu oluştur
    # Bu örnekte, x'in karesi üzerinden bir dönüşüm kullanılmıştır
    return 1 / (1 + np.exp(-alpha * (x - beta))) ** gamma + x**2

#------------Kendi Fonksiyonum----------------------------------------------

#------------yol tespit----------------------------------------------

def detect_lines(image_path):
    # Görüntüyü yükle
    image = cv2.imread(image_path)

    # Görüntünün boyutları
    height, width = image.shape[:2]

    # İlgilenilen bölgeyi belirle (ROI)
    roi_vertices = np.array([[(0, height), (width / 2, height / 2), (width, height)]], dtype=np.int32)
    mask = np.zeros_like(image)
    cv2.fillPoly(mask, roi_vertices, (255, 255, 255))
    masked_image = cv2.bitwise_and(image, mask)

    # Renk uzayı dönüşümü (BGR'den HSV'ye)
    hsv = cv2.cvtColor(masked_image, cv2.COLOR_BGR2HSV)

    # Kenar tespiti yap (Canny kenar dedektörü)
    edges = cv2.Canny(hsv, 150, 200, apertureSize=3)

    # Hough dönüşümünü uygula
    lines = cv2.HoughLinesP(edges, 1, np.pi / 180, threshold=10, minLineLength=400, maxLineGap=100)

    # Tespit edilen çizgileri görüntüye çiz
    if lines is not None:
        for line in lines:
            x1, y1, x2, y2 = line[0]
            cv2.line(image, (x1, y1), (x2, y2), (0, 255, 0), 2)

    return image
#------------yol tespit----------------------------------------------

#------------Göz Yakalama----------------------------------------------

def detect_faces_and_eyes(image_path):
    # Resmi yükle
    image = cv2.imread(image_path)
    gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    # Yüz tespiti
    face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
    faces = face_cascade.detectMultiScale(gray_image, scaleFactor=1.3, minNeighbors=5)

    # Göz tespiti için göz tespit sınıflandırıcısı
    eye_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_eye.xml')

    # Her bir yüz bölgesi için gözleri tespit et
    for (x,y,w,h) in faces:
        cv2.rectangle(image,(x,y),(x+w,y+h),(255,0,0),2) # Yüzü çerçevele

        # Yüz bölgesini al
        roi_gray = gray_image[y:y+h, x:x+w]
        roi_color = image[y:y+h, x:x+w]

        # Gözleri tespit et
        eyes = eye_cascade.detectMultiScale(roi_gray)
        for (ex,ey,ew,eh) in eyes:
            cv2.rectangle(roi_color,(ex,ey),(ex+ew,ey+eh),(0,255,0),2) # Gözleri çerçevele

    return image
#------------Göz Yakalama----------------------------------------------

def deblur_image(image_path):
    # Görüntüyü yükle
    image = cv2.imread(image_path)

    # Bulanıklık modelini belirle (örneğin, 3x3 bir çizgi gibi)
    kernel = np.ones((3, 3), np.float32) / 9

    # Bulanıklık modelini görüntüye uygula
    deblurred_image = cv2.filter2D(image, -1, kernel)

    # Görüntüyü iyileştirme (keskinleştirme)
    enhanced_image = cv2.detailEnhance(deblurred_image, sigma_s=25, sigma_r=0.75)

    return enhanced_image




class ImageProcessor(QWidget):


    def __init__(self):
        super().__init__()
        self.setWindowTitle("Image Processor")
        self.initUI()


    def initUI(self):
        self.setGeometry(400, 200, 1200, 550)
        self.original_image_label = QLabel(self)
        self.original_image_label = QLabel("                   Görüntü yüklemek için yükle butonuna basınız", self)
        self.original_image_label.setGeometry(50, 50, 400, 400)

        self.processed_image_label = QLabel(self)
        self.processed_image_label.setGeometry(750, 50, 400, 400)

        self.process_combobox = QComboBox(self)
        self.process_combobox.setGeometry(500, 75, 200, 30)
        self.process_combobox.addItems(
            ["Standart Sigmoid Fonksiyonu", "Yatay Kaydırılmış Sigmoid Fonksiyonu", "Eğimli Sigmoid Fonksiyonu",
             "Kendi Fonksiyonum"])

        self.run_button = QPushButton("Çalıştır", self)
        self.run_button.setGeometry(550, 110, 100, 30)
        self.run_button.clicked.connect(self.process_image)

        self.lineDetect_button = QPushButton("Line Detection", self)
        self.lineDetect_button.setGeometry(500, 180, 200, 30)
        self.lineDetect_button.clicked.connect(self.Line_Detect)


        self.eyes_button = QPushButton("Eyes Catching", self)
        self.eyes_button.setGeometry(500, 220, 200, 30)
        self.eyes_button.clicked.connect(self.eyes_catch)


        self.deblurring_button = QPushButton("Deblurring", self)
        self.deblurring_button.setGeometry(500, 320, 200, 30)
        self.deblurring_button.clicked.connect(self.Deblurring)


        self.say_button = QPushButton("Counting", self)
        self.say_button.setGeometry(500, 440, 200, 30)
        self.say_button.clicked.connect(self.Counting)


        self.load_button = QPushButton("Yükle", self)
        self.load_button.setGeometry(200, 500, 100, 30)
        self.load_button.clicked.connect(self.load_image)

        # Yeni bir fonksiyon ekleyelim

    def load_image(self):
            # Dosya seçme iletişim kutusunu aç
            filename, _ = QFileDialog.getOpenFileName(self, "Görüntü Yükle", "", "Image Files (*.png *.jpg *.bmp)")

            if filename:
                # Seçilen dosyayı yükle
                pixmap = QPixmap(filename)
                self.original_image_label.setPixmap(pixmap.scaled(self.original_image_label.size()))
                # Seçilen dosyanın yolu `original_image_path` değişkenine atanıyor
                self.original_image_path = filename


    def process_image(self):
        selected_index = self.process_combobox.currentIndex()
        if selected_index == 0:
            self.process_standard()
        elif selected_index == 1:
            self.process_shifted()
        elif selected_index == 2:
            self.process_sloped()
        elif selected_index == 3:
            self.process_custom_s_curve()
    def process_standard(self):
        # Orijinal görüntü yolu
        original_image_path = self.original_image_path

        # Orijinal görüntüyü yükle
        original_image = cv2.imread(original_image_path, cv2.IMREAD_GRAYSCALE)

        # İşlenmiş görüntüyü elde et
        enhanced_image = contrast_enhancement(original_image_path)

        pixmap = QPixmap.fromImage(
            QImage(enhanced_image.data, enhanced_image.shape[1], enhanced_image.shape[0], QImage.Format_Grayscale8))
        self.processed_image_label.setPixmap(pixmap.scaled(self.processed_image_label.size()))
    def process_shifted(self):
        # Orijinal görüntü yolu
        original_image_path = self.original_image_path

        # Orijinal görüntüyü yükle
        original_image = cv2.imread(original_image_path, cv2.IMREAD_GRAYSCALE)

        # İşlenmiş görüntüyü elde et
        enhanced_image = shifted_sigmoid(original_image)

        pixmap = QPixmap.fromImage(
            QImage(enhanced_image.data, enhanced_image.shape[1], enhanced_image.shape[0], QImage.Format_Grayscale8))
        self.processed_image_label.setPixmap(pixmap.scaled(self.processed_image_label.size()))
    def process_sloped(self):
        # Orijinal görüntü yolu
        original_image_path = self.original_image_path

        # Orijinal görüntüyü yükle
        original_image = cv2.imread(original_image_path, cv2.IMREAD_GRAYSCALE)

        # İşlenmiş görüntüyü elde et
        enhanced_image = sloped_sigmoid(original_image)

        pixmap = QPixmap.fromImage(
            QImage(enhanced_image.data, enhanced_image.shape[1], enhanced_image.shape[0], QImage.Format_Grayscale8))
        self.processed_image_label.setPixmap(pixmap.scaled(self.processed_image_label.size()))

    def process_custom_s_curve(self):
        print("1")

        # Orijinal görüntü yolu
        original_image_path = self.original_image_path

        # Orijinal görüntüyü yükle
        original_image = cv2.imread(original_image_path, cv2.IMREAD_GRAYSCALE)

        # İşlenmiş görüntüyü elde et
        enhanced_image = custom_contrast(original_image)
        print("2")

        pixmap = QPixmap.fromImage(
            QImage(enhanced_image.data, enhanced_image.shape[1], enhanced_image.shape[0], QImage.Format_Grayscale8))
        self.processed_image_label.setPixmap(pixmap.scaled(self.processed_image_label.size()))

    def Line_Detect(self):

        # Resim yolu
        image_path = self.original_image_path

        # Çizgileri tespit et
        result_image = detect_lines(image_path)

        # OpenCV görüntüsünü QImage'e dönüştür
        height, width, channel = result_image.shape
        bytesPerLine = 3 * width
        qImg = QImage(result_image.data, width, height, bytesPerLine, QImage.Format_RGB888)

        # QImage'i QPixmap'e dönüştür ve orginal_image_label'a yerleştir
        pixmap = QPixmap.fromImage(qImg)
        self.processed_image_label.setPixmap(pixmap.scaled(self.original_image_label.size()))

        # Sonucu göster
        #cv2.imshow("Detected Lines", result_image)
        #cv2.waitKey(0)
        #cv2.destroyAllWindows()
    def eyes_catch(self):
        image_path = self.original_image_path
        result_image = detect_faces_and_eyes(image_path)

        # OpenCV görüntüsünü QImage'e dönüştür
        height, width, channel = result_image.shape
        bytesPerLine = 3 * width
        qImg = QImage(result_image.data, width, height, bytesPerLine, QImage.Format_RGB888)

        # QImage'i QPixmap'e dönüştür ve orginal_image_label'a yerleştir
        pixmap = QPixmap.fromImage(qImg)
        self.processed_image_label.setPixmap(pixmap.scaled(self.original_image_label.size()))

    def Deblurring(self):
        image_path = self.original_image_path

        # Deblurring işlemini gerçekleştir
        result_image = deblur_image(image_path)

        # OpenCV görüntüsünü QImage'e dönüştür
        result_image_rgb = cv2.cvtColor(result_image, cv2.COLOR_BGR2RGB)
        height, width, channel = result_image.shape
        bytesPerLine = 3 * width
        qImg = QImage(result_image_rgb.data, width, height, bytesPerLine, QImage.Format_RGB888)

        # QImage'i QPixmap'e dönüştür ve orginal_image_label'a yerleştir
        pixmap = QPixmap.fromImage(qImg)
        self.processed_image_label.setPixmap(pixmap.scaled(self.original_image_label.size()))



        # Sonucu göster
        #cv2.imshow("Detected Lines", result_image)
        #cv2.waitKey(0)
        #cv2.destroyAllWindows()

    def Counting(self):

        try:

            dosya_yolu = r"Vize_img\farm.jpg"
            pixmap = QPixmap(dosya_yolu)
            self.original_image_label.setPixmap(pixmap.scaled(self.original_image_label.size()))

            # Uyarı mesajı göster
            QMessageBox.information(self, "Uyarı", "Sırasıyla Aşamaları Görmek İçin Tamam Butonuna Tıklayın Ve Açılan Pencereleri kapatın [(her pencere farkı bir adımı temsil ediyor)]")
            self.processed_image_label.setText("Devam Edin...")
            # Görüntüyü yükle
            image = cv2.imread(r"Vize_img\farm.jpg")
            image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)  # Matplotlib RGB formatını kullanır

            # Görüntüyü gri tonlamaya çevir
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            self.processed_image_label.setText("1. Adımdasın Devam Et...")
            cv2.imshow('gri tonlamaya cevir', cv2.resize(gray, (400,400)))  # Boyutu ayarla
            cv2.moveWindow('gri tonlamaya cevir', 1150, 250)  # Konumu ayarla
            cv2.waitKey(0)


            # Gürültüyü azaltmak için Gaussian Bulanıklığı uygula
            blurred = cv2.GaussianBlur(gray, (9, 9), 0)
            self.processed_image_label.setText("2. Adımdasın Devam Et...")
            cv2.imshow('Gaussian Bulanikligi uygula', cv2.resize(blurred, (400, 400)))  # Boyutu ayarla
            cv2.moveWindow('Gaussian Bulanikligi uygula', 1150, 250)  # Konumu ayarla
            cv2.waitKey(0)


            # Koyu yeşil rengi tespit etmek için bir eşikleme işlemi uygula
            lower_green = np.array([0, 100, 0], dtype="uint8")
            upper_green = np.array([50, 255, 50], dtype="uint8")
            mask = cv2.inRange(image_rgb, lower_green, upper_green)
            self.processed_image_label.setText("3. Adımdasın Devam Et...")
            cv2.imshow('esikleme islemi uygula', cv2.resize(mask, (400, 400)))  # Boyutu ayarla
            cv2.moveWindow('esikleme islemi uygula', 1150, 250)  # Konumu ayarla
            cv2.waitKey(0)

            self.processed_image_label.setText("Tüm Aşamalar Bitmiştir.\n Excel Dosyası Masaüstüne kaydedilmiştir.")



            # Eşiklenmiş görüntü üzerinde kontürleri bul
            contours, _ = cv2.findContours(mask, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)

            # Özellikleri depolamak için bir DataFrame oluştur
            data = []

            # Kontürler üzerinde döngü
            for i, contour in enumerate(contours):
                # Konturun alanını hesapla
                area = cv2.contourArea(contour)

                # Konturun merkezini hesapla
                M = cv2.moments(contour)
                if M['m00'] != 0:  # Sıfıra bölme hatasını önle
                    cx = int(M['m10'] / M['m00'])
                    cy = int(M['m01'] / M['m00'])
                else:
                    cx, cy = 0, 0  # Alan sıfırsa merkez de sıfır olacak

                # Konturun sınırlayıcı dikdörtgenini bul
                x, y, w, h = cv2.boundingRect(contour)

                # Çapı (diagonal) hesapla
                diagonal = np.sqrt(w ** 2 + h ** 2)

                # Enerji ve Entropi hesapla
                energy = cv2.moments(blurred[y:y + h, x:x + w])['nu20'] + cv2.moments(blurred[y:y + h, x:x + w])['nu02']
                entropy = -np.sum(np.where((blurred[y:y + h, x:x + w] != 0),
                                           (blurred[y:y + h, x:x + w] / 255) * np.log(blurred[y:y + h, x:x + w] / 255), 0))

                # Ortalama ve Medyanı hesapla
                mean_val = np.mean(blurred[y:y + h, x:x + w])
                median_val = np.median(blurred[y:y + h, x:x + w])

                # Özellikleri DataFrame'e ekle
                data.append([i + 1, (cx, cy), w, h, diagonal, energy, entropy, mean_val, median_val])

            # DataFrame'i oluştur
            columns = ["No", "Center", "Length", "Width", "Diagonal", "Energy", "Entropy", "Mean", "Median"]
            df = pd.DataFrame(data, columns=columns)

            # DataFrame'i Excel dosyasına kaydet
            # Kullanıcının masaüstü dizini
            desktop_path = os.path.join(os.path.join(os.environ['USERPROFILE']), 'Desktop')

            # Excel dosyasının masaüstüne kaydedilmesi
            df.to_excel(os.path.join(desktop_path, "hiperspektral_ozellikler.xlsx"), index=False)
            print("Excel dosyası oluşturuldu.")

            # Tabloyu göster
            print(df)
        except Exception as e:
            print("Hata oluştu:", e)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = ImageProcessor()
    window.show()
    sys.exit(app.exec_())
